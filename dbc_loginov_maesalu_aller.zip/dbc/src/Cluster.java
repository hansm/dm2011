
public class Cluster {
	public int id;
	public int size;
	
	public Cluster(int id, int size) {
		this.id = id;
		this.size = size;
	}
	
}
